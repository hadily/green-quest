package com.travelappflutter.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
