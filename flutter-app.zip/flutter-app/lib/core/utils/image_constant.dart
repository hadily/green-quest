class ImageConstant {
  static String imgRectangle15 = 'assets/images/img_rectangle15.svg';

  static String imgEllipse8975 = 'assets/images/img_ellipse897_5.png';

  static String imgEllipse21 = 'assets/images/img_ellipse21.png';

  static String imgRectangle8431 = 'assets/images/img_rectangle843_1.png';

  static String imgSignal24x40 = 'assets/images/img_signal_24x40.svg';

  static String imgEllipse25 = 'assets/images/img_ellipse25.png';

  static String imgEllipse8972 = 'assets/images/img_ellipse897_2.png';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgRectangle8383 = 'assets/images/img_rectangle838_3.png';

  static String imgFile1 = 'assets/images/img_file_1.svg';

  static String imgEllipse901 = 'assets/images/img_ellipse901.png';

  static String imgArrowup = 'assets/images/img_arrowup.svg';

  static String imgVector2524 = 'assets/images/img_vector2524.svg';

  static String imgEllipse23 = 'assets/images/img_ellipse23.png';

  static String imgEllipse2124x24 = 'assets/images/img_ellipse21_24x24.png';

  static String imgEllipse8974 = 'assets/images/img_ellipse897_4.png';

  static String imgRectangle818 = 'assets/images/img_rectangle818.png';

  static String imgCheckmark1 = 'assets/images/img_checkmark_1.svg';

  static String imgClock = 'assets/images/img_clock.svg';

  static String imgReply = 'assets/images/img_reply.svg';

  static String imgRectangle2980x80 = 'assets/images/img_rectangle29_80x80.png';

  static String imgAfbea499038243 = 'assets/images/img_afbea499038243.png';

  static String imgEllipse899 = 'assets/images/img_ellipse899.png';

  static String imgEllipse2324x24 = 'assets/images/img_ellipse23_24x24.png';

  static String imgArrowright = 'assets/images/img_arrowright.svg';

  static String imgArrowleft44x44 = 'assets/images/img_arrowleft_44x44.svg';

  static String imgRectangle825 = 'assets/images/img_rectangle825.png';

  static String imgEdit24x24 = 'assets/images/img_edit_24x24.svg';

  static String imgSearchBluegray400 =
      'assets/images/img_search_bluegray_400.svg';

  static String imgEllipse8973 = 'assets/images/img_ellipse897_3.png';

  static String imgRectangle831 = 'assets/images/img_rectangle831.png';

  static String imgCheckmark14x14 = 'assets/images/img_checkmark_14x14.svg';

  static String imgUser24x24 = 'assets/images/img_user_24x24.svg';

  static String imgRectangle845 = 'assets/images/img_rectangle845.svg';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgBookmark44x44 = 'assets/images/img_bookmark_44x44.svg';

  static String imgEllipse903 = 'assets/images/img_ellipse903.png';

  static String imgRectangle838 = 'assets/images/img_rectangle838.png';

  static String imgCheckmark9x12 = 'assets/images/img_checkmark_9x12.svg';

  static String imgRectangle29 = 'assets/images/img_rectangle29.png';

  static String imgLightbulb = 'assets/images/img_lightbulb.svg';

  static String imgLink = 'assets/images/img_link.svg';

  static String imgRectangle823 = 'assets/images/img_rectangle823.png';

  static String imgRectangle14 = 'assets/images/img_rectangle14.svg';

  static String img252a6624a42c117 = 'assets/images/img_252a6624a42c117.png';

  static String imgSettings = 'assets/images/img_settings.svg';

  static String imgRectangle822 = 'assets/images/img_rectangle822.png';

  static String imgBookmark = 'assets/images/img_bookmark.svg';

  static String imgRectangle34 = 'assets/images/img_rectangle34.png';

  static String imgGroup67 = 'assets/images/img_group67.svg';

  static String imgCalendar24x24 = 'assets/images/img_calendar_24x24.svg';

  static String imgSignal = 'assets/images/img_signal.svg';

  static String imgRectangle833 = 'assets/images/img_rectangle833.png';

  static String imgRectangle8381 = 'assets/images/img_rectangle838_1.png';

  static String imgEyeicon = 'assets/images/img_eyeicon.svg';

  static String imgRectangle8432 = 'assets/images/img_rectangle843_2.png';

  static String imgRectangle8382 = 'assets/images/img_rectangle838_2.png';

  static String imgRectangle843 = 'assets/images/img_rectangle843.png';

  static String imgEllipse90155x55 = 'assets/images/img_ellipse901_55x55.png';

  static String imgRectangle843116x95 =
      'assets/images/img_rectangle843_116x95.png';

  static String imgRectangle830 = 'assets/images/img_rectangle830.png';

  static String imgEllipse2524x24 = 'assets/images/img_ellipse25_24x24.png';

  static String imgUser1 = 'assets/images/img_user_1.svg';

  static String imgUser2 = 'assets/images/img_user_2.svg';

  static String imgRectangle824 = 'assets/images/img_rectangle824.png';

  static String imgEllipse897 = 'assets/images/img_ellipse897.png';

  static String imgRectangle839 = 'assets/images/img_rectangle839.svg';

  static String imgRectangle291 = 'assets/images/img_rectangle29_1.png';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgStarYellow600 = 'assets/images/img_star_yellow_600.png';

  static String img7f47f9144194941 = 'assets/images/img_7f47f9144194941.png';

  static String imgFile = 'assets/images/img_file.svg';

  static String imgEdit = 'assets/images/img_edit.svg';

  static String imgCut = 'assets/images/img_cut.svg';

  static String imgCall = 'assets/images/img_call.svg';

  static String imgLocation = 'assets/images/img_location.svg';

  static String imgFavorite = 'assets/images/img_favorite.svg';

  static String imgStar = 'assets/images/img_star.svg';

  static String imgCheckmark = 'assets/images/img_checkmark.svg';

  static String imgGroup335 = 'assets/images/img_group335.png';

  static String imgCheckmark7x10 = 'assets/images/img_checkmark_7x10.svg';

  static String imgTicket = 'assets/images/img_ticket.svg';

  static String imgRectangle838124x137 =
      'assets/images/img_rectangle838_124x137.png';

  static String imgRectangle27 = 'assets/images/img_rectangle27.png';

  static String imgEllipse89748x48 = 'assets/images/img_ellipse897_48x48.png';

  static String imgEye = 'assets/images/img_eye.svg';

  static String imgFile96x96 = 'assets/images/img_file_96x96.svg';

  static String img32badb63498577 = 'assets/images/img_32badb63498577.png';

  static String imgEllipse8971 = 'assets/images/img_ellipse897_1.png';

  static String imgTrash = 'assets/images/img_trash.svg';

  static String imgCalendar = 'assets/images/img_calendar.svg';

  static String imgLocation24x24 = 'assets/images/img_location_24x24.svg';

  static String imgRectangle826 = 'assets/images/img_rectangle826.png';

  static String imgBookmarkWhiteA700 =
      'assets/images/img_bookmark_white_a700.png';

  static String imgRectangle839124x137 =
      'assets/images/img_rectangle839_124x137.png';

  static String imgMaximize = 'assets/images/img_maximize.svg';

  static String imgCheckmark9x16 = 'assets/images/img_checkmark_9x16.svg';

  static String imgHome = 'assets/images/img_home.svg';

  static String imgMicrophone = 'assets/images/img_microphone.svg';

  static String img = 'assets/images/img_.svg';

  static String imgRectangle821 = 'assets/images/img_rectangle821.svg';

  static String imgOverflowmenu = 'assets/images/img_overflowmenu.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
