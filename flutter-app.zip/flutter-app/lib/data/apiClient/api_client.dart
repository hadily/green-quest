import 'package:travelappflutter/core/app_export.dart';

class ApiClient extends GetConnect {}
