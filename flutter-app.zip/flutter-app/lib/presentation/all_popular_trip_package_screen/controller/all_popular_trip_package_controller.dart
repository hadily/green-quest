import '/core/app_export.dart';
import 'package:travelappflutter/presentation/all_popular_trip_package_screen/models/all_popular_trip_package_model.dart';

class AllPopularTripPackageController extends GetxController {
  Rx<AllPopularTripPackageModel> allPopularTripPackageModelObj =
      AllPopularTripPackageModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
