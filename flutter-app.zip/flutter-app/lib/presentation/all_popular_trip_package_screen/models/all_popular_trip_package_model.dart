import 'package:get/get.dart';
import 'listrectangle843_item_model.dart';

class AllPopularTripPackageModel {
  RxList<Listrectangle843ItemModel> listrectangle843ItemList =
      RxList.filled(4, Listrectangle843ItemModel());
}
