class AppNavigationModel {}
