class ChatsModel {}
