class DetailsModel {}
