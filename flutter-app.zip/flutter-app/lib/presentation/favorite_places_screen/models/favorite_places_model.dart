import 'package:get/get.dart';
import 'gridrectangle838_item_model.dart';

class FavoritePlacesModel {
  RxList<Gridrectangle838ItemModel> gridrectangle838ItemList =
      RxList.filled(6, Gridrectangle838ItemModel());
}
