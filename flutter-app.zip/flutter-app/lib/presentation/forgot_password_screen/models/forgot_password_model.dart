class ForgotPasswordModel {}
