class NotificationItemModel {}
