import '/core/app_export.dart';
import 'package:travelappflutter/presentation/onboard_one_screen/models/onboard_one_model.dart';

class OnboardOneController extends GetxController {
  Rx<OnboardOneModel> onboardOneModelObj = OnboardOneModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
