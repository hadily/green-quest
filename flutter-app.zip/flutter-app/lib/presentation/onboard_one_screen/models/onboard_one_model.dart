class OnboardOneModel {}
