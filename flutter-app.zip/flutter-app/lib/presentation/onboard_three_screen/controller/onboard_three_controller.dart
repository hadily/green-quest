import '/core/app_export.dart';
import 'package:travelappflutter/presentation/onboard_three_screen/models/onboard_three_model.dart';

class OnboardThreeController extends GetxController {
  Rx<OnboardThreeModel> onboardThreeModelObj = OnboardThreeModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
