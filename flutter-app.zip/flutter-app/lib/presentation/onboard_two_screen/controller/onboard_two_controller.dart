import '/core/app_export.dart';
import 'package:travelappflutter/presentation/onboard_two_screen/models/onboard_two_model.dart';

class OnboardTwoController extends GetxController {
  Rx<OnboardTwoModel> onboardTwoModelObj = OnboardTwoModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
