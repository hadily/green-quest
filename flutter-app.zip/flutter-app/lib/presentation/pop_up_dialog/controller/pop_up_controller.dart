import '/core/app_export.dart';
import 'package:travelappflutter/presentation/pop_up_dialog/models/pop_up_model.dart';

class PopUpController extends GetxController {
  Rx<PopUpModel> popUpModelObj = PopUpModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
