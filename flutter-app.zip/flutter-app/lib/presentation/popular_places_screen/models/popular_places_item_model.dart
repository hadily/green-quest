class PopularPlacesItemModel {}
