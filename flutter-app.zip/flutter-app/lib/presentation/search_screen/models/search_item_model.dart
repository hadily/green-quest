class SearchItemModel {}
