class SplashModel {}
