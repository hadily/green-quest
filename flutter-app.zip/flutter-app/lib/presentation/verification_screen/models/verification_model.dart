class VerificationModel {}
